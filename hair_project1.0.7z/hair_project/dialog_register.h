﻿#ifndef DIALOG_REGISTER_H
#define DIALOG_REGISTER_H

#include <QDialog>

namespace Ui {
class Dialog_register;
}

class Dialog_register : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog_register(QWidget *parent = nullptr);
    ~Dialog_register();
    //QString getinformation();
    //void setidpwd(QString &value1,QString &value2);

private slots:
    void on_pushButton_clicked();

signals:
    void send(QString a,QString b);

private:
    Ui::Dialog_register *ui;
    //QString rname;
    QString rid;
    QString rpassward;
    //QString rmajor;
};

#endif // DIALOG_REGISTER_H
