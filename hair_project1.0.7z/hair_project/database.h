﻿#ifndef DATABASE_H
#define DATABASE_H
#include <QSqlDatabase>
#include <QVector>
#include "user.h"

class database
{
public:
    database();

    static database *getDatabaseInstence();  //静态的获取数据库对象的函数

    //插入一个用户信息
    bool insertUsr(user &usr);

    //根据ID查找用户
    bool findUsr(QString ID);

    //匹配id和pwd
    bool judge(QString id, QString pwd);


private:
    QSqlDatabase db_;
};

#endif // DATABASE_H
