﻿#include <QMessageBox>
#include"user.h"
#include"database.h"
#include "dialog_register.h"
#include "ui_dialog_register.h"

Dialog_register::Dialog_register(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_register)
{
    ui->setupUi(this);
}

Dialog_register::~Dialog_register()
{
    delete ui;
}
/*
QString Dialog_register::getinformation()
{
     return rid,rpassward;
}

void Dialog_register::setidpwd(QString &value1, QString &value2)
{
    rid=value1;
    rpassward=value2;
}
*/
void Dialog_register::on_pushButton_clicked()
{
    //注册时保存用户注册信息

    QString name=ui->lineEdit_name->text();
    QString id=ui->lineEdit_id->text();
    QString pwd=ui->lineEdit_pwd->text();
    QString sex=ui->radioButton_y->isChecked() ? "Man" : "Woman";
    QString birthday=ui->dateEdit->text();
    QString major=ui->lineEdit_major->text();
    //******************************************************************
    if((!name.isEmpty())&&(!pwd.isEmpty())&&(!id.isEmpty()))
    {
        user user(name,id, pwd, sex, birthday, major);
        database* pdb = database::getDatabaseInstence();
        bool ret = pdb->insertUsr(user);
        if (ret)
        {
            QMessageBox::information(this,
                                     "提示",
                                     "注册成功！",
                                     QMessageBox::Ok);
            //发射信号
            emit send(id,pwd);
        }
    }
    else if(name.isEmpty())
    {
        QMessageBox::information(this,
                                 "提示",
                                 "姓名不能为空！",
                                 QMessageBox::Ok);
    }
    else if(id.isEmpty())
    {
        QMessageBox::information(this,
                                 "提示",
                                 "账号不能为空！",
                                 QMessageBox::Ok);
    }
    else if(pwd.isEmpty())
    {
        QMessageBox::information(this,
                                 "提示",
                                 "密码不能为空！",
                                 QMessageBox::Ok);
    }
    else{
        QMessageBox::information(this,
                                 "提示",
                                 "注册失败！",
                                 QMessageBox::Ok);
    }

    this->close();
}
