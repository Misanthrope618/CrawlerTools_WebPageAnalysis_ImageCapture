﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_toolButton_clicked()
{
    QDir dir;
    PathName = QFileDialog::getExistingDirectory(this, tr("选择文件夹"),
                                                 "E:/Myworkspace/data/",
                                                 QFileDialog::ShowDirsOnly
                                                 | QFileDialog::DontResolveSymlinks);

    PathName.replace("/","\\"); //单斜杠转换双斜杠,方便后续存储bin文件
    //    current_File_time =QDateTime::currentDateTime();
    //    current_File="images";//默认文件夹名
    //    PathName = PathName+ "\\"+current_File ;
    ui->PathShow->setText(PathName);    //文件名称显示
    //    dir.mkdir(PathName);    //在目录下创建新文件夹
}

void MainWindow::on_pushButton_2_clicked()
{
    //调用爬取图片的.py
    //getpy();

    //判断路径是否存在
    QDir dir(PathName);
    if(!dir.exists())
        return;

    //查看路径中后缀为.jpg格式的文件
    QStringList filters;
    filters<<QString("*.jpg");
    dir.setFilter(QDir::Files | QDir::NoSymLinks); //设置类型过滤器，只为文件格式
    dir.setNameFilters(filters);  //设置文件名称过滤器，只为filters格式

    //统计cfg格式的文件个数
    int dir_count = dir.count();
    if(dir_count <= 0){
        return;
    }
    //存储文件名称
    for(int i=0; i<dir_count; i++)
    {
        QString file_name = dir[i];  //文件名称
        qDebug()<<file_name;
        fileNames.append(file_name);
    }

    showImageList();
}

void MainWindow::showImageList()
{
    ui->listWidget->clear();
    //设置QListWidget的显示模式
    ui->listWidget->setViewMode(QListView::IconMode);
    //设置QListWidget中单元项的图片大小
    ui->listWidget->setIconSize(QSize(100,100));
    //设置QListWidget中单元项的间距
    ui->listWidget->setSpacing(5);
    //设置自动适应布局调整（Adjust适应，Fixed不适应），默认不适应
    ui->listWidget->setResizeMode(QListWidget::Adjust);
    //设置不能移动
    ui->listWidget->setMovement(QListWidget::Static);
    for(auto tmp : fileNames)
    {
        QString  path = PathName+ "\\"+tmp ;
        //定义QListWidgetItem对象
        QListWidgetItem *imageItem = new QListWidgetItem;
        //为单元项设置属性
        imageItem->setIcon(QIcon(path));
        //imageItem->setText(tr("Browse"));
        //重新设置单元项图片的宽度和高度
        QImage image(path);
        qDebug()<<"current size:"<<image.width()<<image.height();
        //imageItem->setSizeHint(QSize(image.width(),image.height()));
        imageItem->setSizeHint(QSize(100,100));
        //将单元项添加到QListWidget中
        ui->listWidget->addItem(imageItem);
    }
    //显示QListWidget
    ui->listWidget->show();
}

void MainWindow::getpy()
{
    Py_Initialize();
    //如果初始化失败，返回
    if(!Py_IsInitialized())
    {
        qDebug()<<"Python init fail!";
        //return a.exec();
    }
    //设置python文件路径
    PyRun_SimpleString("import sys");
    PyRun_SimpleString("sys.path.append('C:/Users/Lenovo/Desktop/file/hair/hair_project/ImagewsGet.py')");

    //加载test.py文件
    PyObject *pModule = PyImport_ImportModule("ImagesGet"); //注意python文件不要取名为test.py,会与python库文件冲突
    if(!pModule)
    {
        qDebug()<<"load pModule(ImagesGet.py) fail!";
        //return a.exec();
    }

    //加载函数sum（有参）
    PyObject* pFun_get= PyObject_GetAttrString(pModule,"get");
    if(!pFun_get)
    {
        qDebug()<<"Get pFun_get(get) failed!";
        //return a.exec();
    }


 //PyEval_CallObject(pFun_get,NULL);
    //调用函数sum
    PyObject* args=PyTuple_New(3);
    //【例 1】：输入参数：int  输出参数：int
    //【例 3】：输入参数：QString  输出参数：QString
    int iin2=ui->spinBox->text().toInt();
    QString strin1=ui->lineEdit_2->text(),strin2=PathName; //输入参数赋值
    PyTuple_SetItem(args,0,Py_BuildValue("s",strin1.toStdString().c_str()));
    PyTuple_SetItem(args,1,Py_BuildValue("i",iin2));
    PyTuple_SetItem(args,2,Py_BuildValue("s",strin2.toStdString().c_str()));
    PyObject* pReturn1=PyEval_CallObject(pFun_get,args);
    if(PyLong_Check(pReturn1))
    {
        int iout =PyLong_AsLong(pReturn1);
        qDebug()<<iout;  //打印输出
    }
    else
        qDebug()<<"return type is not Long!";

    Py_Finalize(); //释放python
}
