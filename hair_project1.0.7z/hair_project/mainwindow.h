﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include "QDir"
#include "QFileDialog"
#include "QDateTime"
#include"Python.h"

//解决 Python 和 Qt 的关键词 slots 冲突
#pragma push_macro("slots")
#undef slots
#include <Python.h>
#pragma pop_macro("slots")

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:


    //选择文件夹
    void on_toolButton_clicked();

    //爬取图片
    void on_pushButton_2_clicked();

    //将图片缩略图显示在下方
    void showImageList();

    //调用py
    void getpy();

private:
    Ui::MainWindow *ui;
    QString PathName;
    QStringList fileNames;
};

#endif // MAINWINDOW_H
