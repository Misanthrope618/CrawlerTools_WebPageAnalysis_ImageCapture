﻿#ifndef USER_H
#define USER_H

#include<QString>


class user
{
public:
    //构造
    user(QString name="", QString id="",QString pwd="", QString sex="", QString birthday="", QString major="");

    //获取用户名
    QString name() const;
    //设置用户名
    void setName(const QString &name);

    //获取用户id
    QString id() const;
    //设置用户id
    void setID(const QString &id);

    //获取用户密码
    QString pwd() const;
    //设置用户密码
    void setPwd(const QString &pwd);

    //获取用户性别
    QString sex() const;
    //设置用户性别
    void setSex(const QString &sex);

    //获取用户出生日期
    QString birthday() const;
    //设置用户出生日期
    void setBirthday(const QString &birthday);

    //获取用户职业
    QString major() const;
    //设置用户职业
    void setMajor(const QString &major);

public:
    QString name_;//用户昵称
    QString id_;//用户ID（限定为六位数字）
    QString pwd_;//密码
    QString sex_;//用户性别
    QString birthday_;//出生日期
    QString major_;//身份
};

#endif // USER_H
