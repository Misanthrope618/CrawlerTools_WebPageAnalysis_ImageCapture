﻿#include "user.h"


user::user(QString name,
           QString id,
           QString pwd,
           QString sex,
           QString birthday,
           QString major):
    name_(name),
    id_(id),
    pwd_(pwd),
    sex_(sex),
    birthday_(birthday),
    major_(major)
{

}

QString user::name() const
{
    return name_;
}

void user::setName(const QString &name)
{
    name_ = name;
}
QString user::id() const
{
    return id_;
}
void user::setID(const QString &id)
{
    id_=id;
}
QString user::pwd() const
{
    return pwd_;
}

void user::setPwd(const QString &pwd)
{
    pwd_ = pwd;
}
QString user::sex() const
{
    return sex_;
}

void user::setSex(const QString &sex)
{
    sex_ = sex;
}
QString user::birthday() const
{
    return birthday_;
}

void user::setBirthday(const QString &birthday)
{
    birthday_ = birthday;
}
QString user::major() const
{
    return major_;
}

void user::setMajor(const QString &major)
{
    major_ = major;
}

