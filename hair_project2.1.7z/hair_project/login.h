﻿#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class login; }
QT_END_NAMESPACE

class login : public QMainWindow
{
    Q_OBJECT

public:
    login(QWidget *parent = nullptr);
    ~login();
signals:
    //登录成功后发射信号
    void sendUsrname(QString name);
private slots:


    //注册
    void on_pushButton_register_clicked();

    //登录
    void on_pushButton_login_clicked();

    void receive(QString suerid,QString passward);


private:
    Ui::login *ui;
};
#endif // LOGIN_H
